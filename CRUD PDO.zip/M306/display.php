<html>
    <head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Questrial&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@200&display=swap" rel="stylesheet">
    <style>
        .content-table{
            border-collapse: collapse; /**Reduces the amount of space between the cells*/
            margin: 25px 0;     /**Space between the content top and bottom*/
            font-size: 1.2em;
            width: 100%;   /**Ensures that the table is always big, no matter what the content is*/
            font-family: Questrial;
        } 
        
        .content-table thead tr { /**thead and tr tags of class ".content-table"*/
            background-color: #0E25CB;
            color: white;
            text-align: left;
            font-weight: bold;
        }

        .content-table th,
        .content-table td {
            padding: 12px 15px; 
        }

        .content-table tbody tr {           /**Every tr inside the tbody*/
            border-bottom: 1px ridge lightgrey;   /**It needs a Border style(dotted, dashed, solid, double, ridge...)*/
        }

        /** .content-table tbody tr:nth-of-type(even) {
        background-color: #f3f3f3;
        }*/ /**Should add a different color to the odd/even row*/

        h1 {
            font-size:1.9em;
            text-align: center;
            font-family: Outfit;
        }

        .flexbox{
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            align-content: flex-start;
        }

        a{
         text-decoration: none;
         color: Black;  
        }

        input[type=reset] {
        padding: 5px 15px;
        background:orange;
        border: 0 none;
        cursor: pointer;
        -webkit-border-radius: 5px;
        border-radius: 5px;
        margin-top: -21px;
        }

        input[type=reset]:hover {
        background:#99e0b2;
        }

        input[type=submit] {
        padding: 5px 15px;
        background:orange;
        border: 0 none;
        cursor: pointer;
        -webkit-border-radius: 5px;
        border-radius: 5px;
        margin-top: -21px;
        }

        input[type=submit]:hover {
        background:#99e0b2;
        }

        a:hover {
        color: #99e0b2;
        }
        a:active {
        color: blue;
        }


    </style>
    </head>

<?php
        require_once('con_.php');

        $sql = "SELECT * from gefängnissinsassen";

        $ergebnis = $connection->query($sql);

        $anzahl = $ergebnis->rowCount();

        //echo "<p>Die Abfrage hat $anzahl Datensätze gefunden<p>";

?>

<body>

<h1>Datenbank / Gefängnisinsasse </h1>

<div class="flexbox">
<table class="content-table">
<form action = "pdfgen.php" method = "post">

 <thead>
        <tr><th>PDF</th><th>UPDATE</th><th>DELETE</th><th>Name</th><th>Vorname</th><th>Geschlecht</th><th>Age</th><th>Strasse</th><th>Hausnummer</th><th>Postleitzahl</th><th>Datum_Festnahme</th></tr>
</thead>

    <?php

        while($zeile = $ergebnis->fetchObject())
        {
            echo "<tbody><tr><td><input type='radio' name='auswahl' value='" . $zeile->Insasse_ID . "'></td><td>" . 

                "<input type='radio' name='update' value='" . $zeile->Insasse_ID . "'></td><td>" . 

                "<input type='radio' name='delete' value='" . $zeile->Insasse_ID . "'></td><td>" . 

                $zeile->Name."</td><td>".
                $zeile->Vorname."</td><td>".
                $zeile->Geschlecht."</td><td>".
                $zeile->Age."</td><td>".
                $zeile->Strasse."</td><td>".
                $zeile->Hausnummer."</td><td>".
                $zeile->Postleitzahl."</td><td>".
                $zeile->Datum_Festnahme."</td></tr></tbody>";

        }
    ?>

<tfoot>

        <tr><td><input type="reset" value="Zurücksetzen"></td><td><a href="insert.php"><h3>Prompt inmate</h3></a></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td><input id="commit" type='submit' value='SUBMIT' ></td></tr>
</tfoot>

</form>

</table>
</div>
</body>
</html>