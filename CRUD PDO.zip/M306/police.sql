
--
-- Database: `police`
--

-- --------------------------------------------------------

--
-- Table structure for table `delikt`
--

CREATE DATABASE police
USE police

CREATE TABLE `delikt` (
  `Insasse_ID` int(11) NOT NULL,
  `Beschreibung` varchar(100) NOT NULL,
  `Datum_der_Tat` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `gefängnissinsassen`
--

CREATE TABLE `gefängnissinsassen` (
  `Insasse_ID` int(10) NOT NULL,
  `Name` varchar(40) DEFAULT NULL,
  `Vorname` varchar(40) DEFAULT NULL,
  `Geschlecht` varchar(20) DEFAULT NULL,
  `Age` int(11) DEFAULT NULL,
  `Strasse` varchar(36) DEFAULT NULL,
  `Hausnummer` int(11) DEFAULT NULL,
  `Postleitzahl` int(11) DEFAULT NULL,
  `Datum_Festnahme` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `gefängnissinsassen`
--

INSERT INTO `gefängnissinsassen` (`Insasse_ID`, `Name`, `Vorname`, `Geschlecht`, `Age`, `Strasse`, `Hausnummer`, `Postleitzahl`, `Datum_Festnahme`) VALUES
(12, 'Escobar Gavidia', 'Pablo Emilio', 'Männlich', 38, 'Musterstrasse', 10, 1234, '0000-00-00 00:00:00'),
(33, 'Muster', 'Max', 'Muster geschlecht', 32, 'Musterstrasse', 22, 7672, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `UserID` int(11) NOT NULL,
  `username` varchar(36) NOT NULL,
  `password` varchar(36) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`UserID`, `username`, `password`) VALUES
(2, 'user69', 'admin123'),
(10, 'user12', 'password12');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `gefängnissinsassen`
--
ALTER TABLE `gefängnissinsassen`
  ADD PRIMARY KEY (`Insasse_ID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`UserID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

