<html>
<head>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@1,100&display=swap" rel="stylesheet">
</head>
<style>
    .meldung{
    font-family: Roboto;
    }
    #logout {
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        align-content: center;
        color: red;
        font-family: helvetica;
        font-size: 1.5em;
    }
</style>
</html>
<?php
session_start();
if(isset($_SESSION["username"]))
{
    echo '<h3 class="meldung">Eingeloggt als - ' .$_SESSION["username"]. '</h3>';

    require_once('display.php');

    echo '<br><a id="logout" href="index.php">Logout</a>';
}
else{
    header("location:index.php"); //If the username or password is wrong, it will redirect you to that index.php file/ Login.
}
?>