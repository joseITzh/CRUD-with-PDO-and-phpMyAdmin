<html>
  <head>
    <title>Insert data into Users table</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300&display=swap" rel="stylesheet">
    <style>

        * {
            padding: 0;
            margin: 0;
            box-sizing: border-box;
        }

        body {
            background: #f7f7f7;
            font-family: rubik;
            font-weight: 700;
        }

        h2 {
            padding: 20px;
            border-bottom: 2px solid #e6e6f2;
        }

        .d_flex {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            flex-wrap: wrap;
            padding: 20px 0 0;
        }

        .col_1,
        .col_2 {
            padding: 0 15px;
        }

        .col_1 {
            width: 100%;
        }

        .col_2 {
            width: 50%;
        }

        .form_group {
            margin: 0 0 25px;
        }

        .form_group label,
        .form_group input {
            display: block;
        }

        .form_group label {
            margin: 0 0 10px;
        }

        input,
        button {
            width: 100%;
            height: 50px;
        }

        input {
            border: 1px solid #d2d2e4;
            padding: 0 15px;
            color: #71748d;
        }

        button {
            border: none;
            border-top: 2px solid #e6e6f2;
            background: #f6f6ff;
            color: #5969ff;
            font-weight: 700;
            cursor: pointer; /**The cursor changes, when hovers over a button*/
            font-size: 1em;
            font-family: rubik;
        }
        a {
            border: none;
            border-top: 2px solid #e6e6f2;
            background: #f6f6ff;
            color: #5969ff;
            font-weight: 700;
            cursor: pointer; /**The cursor changes, when hovers over a button*/
            font-family: rubik;
            width: 100%;
            height: 50px;
            text-decoration: none;
        }

        .divbutton{
            width: 100%;
            height: 50px;
            background: #f6f6ff;
            text-align: center;
            margin-top: 4px;
            padding: 0.9em;
        }
        

    </style>
  </head>

    <?php

    if(isset($_POST['add_inmate'])){
        
      try {
      // connect to mysql
      require_once('con_.php');

      } catch (PDOException $exc) {
        echo $exc->getMessage();
        exit();
      }

      // Get values from submitted form
      $Insasse_ID = $_POST['Insasse_ID'];
      $Name = $_POST['Name'];
      $Vorname = $_POST['Vorname'];
      $Geschlecht = $_POST['Geschlecht'];
      $Age = $_POST['Age'];
      $Strasse = $_POST['Strasse'];
      $Hausnummer = $_POST['Hausnummer'];
      $Postleitzahl = $_POST['Postleitzahl'];
      $Datum_Festnahme = $_POST['Datum_Festnahme'];

      // Mysql query to insert data
      $sql = "INSERT INTO `gefängnissinsassen`(`Insasse_ID`, `Name`, `Vorname`, `Geschlecht`, `Age`, `Strasse`, `Hausnummer`, `Postleitzahl`, `Datum_Festnahme`) VALUES (:Insasse_ID,:Name, :Vorname, :Geschlecht, :Age, :Strasse, :Hausnummer, :Postleitzahl, :Datum_Festnahme)";
      $res = $connection->prepare($sql);
      $exec = $res->execute(array(":Insasse_ID"=>$Insasse_ID,":Name"=>$Name,":Vorname"=>$Vorname, ":Geschlecht"=>$Geschlecht, ":Age"=>$Age, ":Strasse"=>$Strasse, ":Hausnummer"=>$Hausnummer, ":Postleitzahl"=>$Postleitzahl, ":Datum_Festnahme"=>$Datum_Festnahme ));

      // check if the request was executed successfuly
      if($exec){
        echo 'Data inserted';
      }else{
        echo "ERROR!";
      }
    }
    ?>

  <body>
    <div id="inmate">
        <form action="insert.php" method="POST" id="inmate_form">
            <h2>Add Inmate</h2>
            <div class="d_flex">
                <div class="form_group col_2">
                    <label for="fname">Insasse_ID</label>
                    <input type="text" id="Insasse_ID" name="Insasse_ID" placeholder="Enter inmate's ID">
                </div>
                <div class="form_group col_2">
                    <label for="lname">Name</label>
                    <input type="text" id="Name" name="Name" placeholder="Enter inmate's last name">
                </div>
                <div class="form_group col_2">
                    <label for="lname">Vorname</label>
                    <input type="text" id="Vorname" name="Vorname" placeholder="Enter inmate's first name">
                </div>
                <div class="form_group col_2">

                    <label for="lname">Geschlecht</label>
                    <input type="text" name="Geschlecht" placeholder="Enter inmate's first name">
                </div>
                <div class="form_group col_2">
                    <label for="lname">Age</label>
                    <input type="text" name="Age" placeholder="Enter inmate's first name">
                </div>
                <div class="form_group col_2">
                    <label for="lname">Strasse</label>
                    <input type="text" name="Strasse" placeholder="Enter inmate's first name">
                </div>
                <div class="form_group col_2">
                    <label for="lname">Hausnummer</label>
                    <input type="text" name="Hausnummer" placeholder="Enter inmate's first name">
                </div>
                <div class="form_group col_2">
                    <label for="lname">Postleitzahl</label>
                    <input type="text" name="Postleitzahl" placeholder="Enter inmate's first name">
                </div>
                <div class="form_group col_2">
                    <label for="lname">Datum_Festnahme</label>
                    <input type="datetime" name="Datum_Festnahme" placeholder="Enter inmate's first name">
                </div>
            </div>
                    <button type="submit" name="add_inmate"><h4>Add data</h4></button>
                    
        </form>
        <div class="divbutton"><a href="login_success.php"><h4>Go back</h4></a><div>
    </div>
</body>
</html>