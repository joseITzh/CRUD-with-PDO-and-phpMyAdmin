<html>
  <head>
    <title>Insert data into Users table</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Questrial&display=swap" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <style>

        * {
            padding: 0;
            margin: 0;
            box-sizing: border-box;
        }

        body {
            background: #f7f7f7;
            font-family: Questrial;
            font-weight: 700;
        }

        h2 {
            padding: 20px;
            border-bottom: 2px solid #e6e6f2;
            text-align: center;
        }

        .d_flex {
            flex-direction: column;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            padding: 20px 0 0;
        }

        .col_1,
        .col_2 {
            padding: 0 15px;
        }

        .col_1 {
            width: 100%;
        }

        .col_2 {
            width: 50%;
        }

        .form_group {
            margin: 0 0 25px;
        }

        .form_group label,
        .form_group input {
            display: block;
        }

        .form_group label {
            margin: 0 0 10px;
        }

        input,
        button {
            width: 100%;
            height: 50px;
        }

        input {
            border: 1px solid #d2d2e4;
            padding: 0 15px;
            color: #71748d;
        }

        button {
            border: none;
            border-top: 2px solid #e6e6f2;
            background: #f6f6ff;
            color: #5969ff;
            font-weight: 700;
            cursor: pointer; /**The cursor changes, when hovers over a button*/
            font-size: 1em;
            font-family: Helvetica;
        }
        a {
            border: none;
            border-top: 2px solid #e6e6f2;
            background: #f6f6ff;
            color: #5969ff;
            font-weight: 700;
            cursor: pointer; /**The cursor changes, when hovers over a button*/
            font-family: rubik;
            width: 100%;
            height: 50px;
            text-decoration: none;
        }

        .divbutton{
            width: 100%;
            height: 50px;
            background: #f6f6ff;
            text-align: center;
            margin-top: 4px;
            padding: 0.9em;
        }
        

    </style>
  </head>

<?php
session_start();


try{

    require_once('con_.php');

    $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if(isset($_POST["login"]))
    {
        if(empty($_POST["username"]) || empty($_POST["password"]))
        {
            $message = '<label>All fields are required</label>';
        }
        else{
            $query = "SELECT * FROM users WHERE username = :username AND password = :password";
            $statement = $connection->prepare($query);
            $statement->execute(

                array(
                'username' => $_POST["username"],
                'password' => $_POST["password"]
                )
            );
            $count = $statement->rowCount();
            if($count > 0)
            {
                $_SESSION["username"] = $_POST["username"];
                header("location:login_success.php");
            }
            else{
                $message = '<label>Username or Password is wrong</label>';
            }
        }
    }
}

catch(PDOException $error)
{
    $message = $error->getMessage();
}

?>

<?php
if(isset($message))
{
    '<label>'.$message.'</label>';
}
?>

<body>
    <div id="inmate">
        <form method="POST">
            <h2 id="title">Herzlich willkomen zu meiner App, bitte loge dich ein, um mit der Datenbank zu interagieren</h2>
            <div class="d_flex">

                <div class="form_group col_2">
                    <label for="fname">Username</label>
                    <input type="text" name="username" placeholder="Enter inmate's ID">
                </div>
                <div class="form_group col_2">
                    <label for="lname">Password</label>
                    <input type="password" name="password" placeholder="Enter inmate's last name">
                </div>
                
            </div>
                <button type="submit" name="login"><h4>Login</h4></button>
        </form>
    </div>
</body>

</html>