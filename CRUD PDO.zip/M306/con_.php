<?php

$host = 'localhost';
$dbname = 'police';
$username = 'root';
$password = '';

$message = "";

//Technologie-> Host/Oder IP-Adresse vom Server-> Database name-> user-> password
$connection = new PDO("mysql:host=$host;dbname=$dbname","$username","$password");

?>