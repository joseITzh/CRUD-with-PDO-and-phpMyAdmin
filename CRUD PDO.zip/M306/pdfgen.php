<?php
require_once('fpdf/fpdf.php');
require_once('con_.php');

if(isset($_POST['auswahl']))
{
    $sql = "SELECT * from gefängnissinsassen WHERE Insasse_ID = " . intval($_POST["auswahl"]);

    $ergebnis = $connection->query($sql);

    $pdf = new FPDF(orientation:'p', unit:'mm', size:'a4');
    $pdf->SetFont(family:'arial', style: 'b', size: '8');
    $pdf->AddPage();

    //Einstellung für überschrifft

    $pdf->SetDrawColor(78,52,46);
    $pdf->SetFillColor(255,235,238);
    $pdf->SetTextColor(40,53,147);

    $pdf->Cell(50,20, "Profil vom Insasse:", ln:'1');

    $pdf->cell(w:'35', h:'15', txt:'Inmate ID', border:'1', ln:'0');
    $pdf->cell(w:'35', h:'15', txt:'Name', border:'1', ln:'0');
    $pdf->cell(w:'35', h:'15', txt:'Vorname', border:'1', ln:'1');
    
    
    while($rows = $ergebnis->fetchObject())
    {
        $pdf->cell(w:'35', h:'15', txt:"$rows->Insasse_ID", border:'1', ln:'0');
        $pdf->cell(w:'35', h:'15', txt:"$rows->Name", border:'1', ln:'0');
        $pdf->cell(w:'35', h:'15', txt:"$rows->Vorname", border:'1', ln:'1');

    }
    /**Die Methode Cell() erzeugt eine rechteckige Zelle. Die Methode hat acht Parametern: 
    Breite, Höhe, Text, Festlegung des Randes...*/
    
    //Die Methode Output dient zur Ausgabe des PDF-Objekts.
    $pdf->Output();
}

?>

<?php
require_once('con_.php');

if(isset($_POST['delete'])){

$sql = "DELETE from gefängnissinsassen WHERE Insasse_ID = " . intval($_POST["delete"]);

$ergebnis = $connection->query($sql);

require_once('login_success.php');
}
?>

<?php
require_once('con_.php');

if(isset($_POST['update'])){

require_once("update.php");
}
?>